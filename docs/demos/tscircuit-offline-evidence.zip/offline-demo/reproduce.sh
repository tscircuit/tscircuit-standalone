#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
standalone_binary=$(realpath "${1:?Pass the compiled Linux x64 standalone executable}")
system_bun=$(realpath "${2:?Pass a Bun executable to verify it remains unchanged}")
demo_dir=$PWD
docker build -t tsci-offline-recording .
docker run -d --name tsci-offline-video --network none --cap-add SYS_PTRACE \
  --mount "type=bind,src=$standalone_binary,dst=/usr/local/bin/tsci,readonly" \
  --mount "type=bind,src=$system_bun,dst=/opt/system-bun/bun,readonly" \
  --mount "type=bind,src=$demo_dir,dst=/evidence" \
  --mount "type=bind,src=$demo_dir/demo.sh,dst=/demo/demo.sh,readonly" \
  --mount "type=bind,src=$demo_dir/audit.py,dst=/demo/audit.py,readonly" \
  tsci-offline-recording
python3 record.py
python3 render.py
