import codecs
import json
import pathlib
import subprocess
import time

root = pathlib.Path(__file__).parent
start = time.monotonic()
cast = open(root / 'offline-demo.cast', 'w')
raw = open(root / 'terminal-output.txt', 'w')
cast.write(json.dumps({'version': 2, 'width': 116, 'height': 34, 'timestamp': int(time.time()), 'env': {'TERM': 'xterm-256color'}, 'title': 'TS Circuit — Docker with no internet'}) + '\n')

def emit(s):
    cast.write(json.dumps([round(time.monotonic()-start, 4), 'o', s]) + '\n')
    cast.flush()
    raw.write(s)
    raw.flush()

def command(args, shown):
    emit('\033[1;32mhost$\033[0m ' + shown + '\r\n')
    time.sleep(1)
    child = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    decoder = codecs.getincrementaldecoder('utf-8')('replace')
    while True:
        b = child.stdout.read1(4096)
        if not b:
            break
        emit(decoder.decode(b).replace('\r\n', '\n').replace('\n', '\r\n'))
    emit(decoder.decode(b'', final=True))
    code = child.wait()
    if code:
        emit(f'\r\nRecording command exited {code}\r\n')
        raise SystemExit(code)

emit('\033[2J\033[H\033[1;36mTS CIRCUIT / OFFLINE DOCKER DEMO\033[0m\r\n\r\n')
emit('Actual terminal output. Image prepared before network isolation.\r\n')
emit('Fresh container: no host caches or project dependencies mounted.\r\n\r\n')
emit('Container launch used: docker run --network none ...\r\n\r\n')
command(['docker', 'inspect', '--format', 'Network mode: {{.HostConfig.NetworkMode}}', 'tsci-offline-video'], "docker inspect --format 'Network mode: {{.HostConfig.NetworkMode}}' tsci-offline-video")
time.sleep(3)
command(['docker', 'exec', '-t', 'tsci-offline-video', 'bash', '/demo/demo.sh'], 'docker exec -it tsci-offline-video bash /demo/demo.sh')
emit('\r\n')
command(['docker', 'inspect', '--format', 'Network mode: {{.HostConfig.NetworkMode}}', 'tsci-offline-video'], "docker inspect --format 'Network mode: {{.HostConfig.NetworkMode}}' tsci-offline-video")
time.sleep(4)
emit('\r\nRecording complete.\r\n')
cast.close()
raw.close()
print(f'Recorded {time.monotonic()-start:.1f}s of real terminal activity')
