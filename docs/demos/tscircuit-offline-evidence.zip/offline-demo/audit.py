import glob
import re

paths = glob.glob('/evidence/*.trace')
assert paths, 'No trace files'
attempts = []
children = []
loopback_sends = 0
local_address = re.compile(r'inet_addr\("127\.[0-9.]+"\)|inet_pton\(AF_INET6, "(?:::1|::ffff:127\.[0-9.]+)"')
for path in paths:
    local_sockets = set()
    for line in open(path):
        if local_address.search(line):
            if re.match(r'^\d+\s+connect\(', line):
                socket = re.search(r'<TCP:\[(\d+)\]>', line)
                if socket:
                    local_sockets.add(socket[1])
            if re.match(r'^\d+\s+accept4?\(', line):
                socket = re.search(r'= \d+<TCP:\[(\d+)\]>', line)
                if socket:
                    local_sockets.add(socket[1])
        if re.search(r'\bexecve\("/usr/local/bin/tsci", \[.*"--config=.*bunfig.toml"', line):
            children.append(line.strip())
        if not re.match(r'^\d+\s+(?:connect|sendto|sendmsg|sendmmsg)\(', line):
            continue
        if re.search(r'\b(?:sendto|sendmsg|sendmmsg)\(\d+<UNIX-STREAM', line):
            continue
        if local_address.search(line):
            continue
        socket = re.search(r'<TCP:\[(\d+)\]>', line)
        if socket and socket[1] in local_sockets and re.search(r'\bsendto\(.*NULL, 0\)', line):
            loopback_sends += 1
            continue
        attempts.append(line.strip())
print(f'Traced CLI invocations: {len(paths)}')
print(f'Embedded executable used for package-manager children: {len(children)}')
print(f'Local-only sends (verified loopback peers): {loopback_sends}')
print(f'External connection/send attempts: {len(attempts)}')
for line in attempts:
    print(line)
assert not attempts, 'Unexpected network attempt'
assert children, 'Embedded runtime child not observed'
print('PASS: native Bun cache; zero external network attempts')
