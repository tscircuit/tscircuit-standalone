import json
import math
from pathlib import Path
import subprocess

import pyte
from PIL import Image, ImageDraw, ImageFont

root = Path(__file__).parent
lines = (root / 'offline-demo.cast').read_text().splitlines()
meta = json.loads(lines[0])
events = []
previous = 0
adjusted = 0
for line in lines[1:]:
    t, kind, data = json.loads(line)
    adjusted += min(t - previous, 4)
    previous = t
    if kind == 'o':
        events.append((adjusted, data))
duration = adjusted + 5
width, height, fps = 1600, 1080, 10
screen = pyte.Screen(meta['width'], meta['height'])
stream = pyte.Stream(screen)
font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf', 20)
bold = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf', 20)
title = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 30)
small = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 18)
colors = {'default': '#dbe5f2', 'black': '#0d1423', 'red': '#ff7786', 'green': '#72e6a3', 'brown': '#edc379', 'blue': '#7aa9ff', 'magenta': '#c69aff', 'cyan': '#76dfe8', 'white': '#f4f7fc', 'brightblack': '#7a8da5', 'brightred': '#ff7786', 'brightgreen': '#72e6a3', 'brightyellow': '#ffe395', 'brightblue': '#9bbfff', 'brightmagenta': '#d3b1ff', 'brightcyan': '#95f1f6', 'brightwhite': '#ffffff'}

def color(c):
    return colors.get(c, '#' + c if len(c) == 6 else '#dbe5f2')

ff = subprocess.Popen(['ffmpeg', '-hide_banner', '-loglevel', 'error', '-y', '-f', 'rawvideo', '-pixel_format', 'rgb24', '-video_size', f'{width}x{height}', '-framerate', str(fps), '-i', '-', '-c:v', 'libx264', '-preset', 'fast', '-crf', '19', '-pix_fmt', 'yuv420p', '-movflags', '+faststart', str(root / 'tscircuit-offline-docker.mp4')], stdin=subprocess.PIPE)
idx = 0
last = None
frame = None
for n in range(math.ceil(duration * fps)):
    now = n / fps
    changed = False
    while idx < len(events) and events[idx][0] <= now:
        stream.feed(events[idx][1])
        idx += 1
        changed = True
    if changed or frame is None or n % fps == 0:
        frame = Image.new('RGB', (width, height), '#080e19')
        d = ImageDraw.Draw(frame)
        d.text((52, 26), 'tscircuit  /  offline CLI demo', font=title, fill='#f4f7fc')
        d.text((54, 72), 'Embedded Bun 1.4.4  •  CLI 0.1.2430  •  standalone PR #46', font=small, fill='#93a8c2')
        d.rounded_rectangle((1190, 24, 1548, 83), radius=13, fill='#12392e', outline='#337e61')
        d.text((1213, 43), 'DOCKER  •  NETWORK NONE', font=small, fill='#8df1b5')
        d.rounded_rectangle((36, 118, 1564, 1006), radius=14, fill='#0d1423', outline='#29374c')
        for y in range(screen.lines):
            for x, char in screen.buffer[y].items():
                if char.data.strip():
                    fg = color(char.fg)
                    if char.reverse:
                        d.rectangle((58+x*12.04, 136+y*25, 70+x*12.04, 161+y*25), fill=fg)
                        fg = '#0d1423'
                    d.text((58+x*12.04, 136+y*25), char.data, font=bold if char.bold else font, fill=fg)
        d.text((52, 1030), 'Real terminal output  •  Long idle pauses shortened  •  Network trace included', font=small, fill='#93a8c2')
        d.text((1405, 1030), f'{int(now)//60:02d}:{int(now)%60:02d} / {int(duration)//60:02d}:{int(duration)%60:02d}', font=small, fill='#93a8c2')
        if changed:
            last = frame.copy()
    ff.stdin.write(frame.tobytes())
ff.stdin.close()
assert ff.wait() == 0
last.save(root / 'preview.png')
print(f'Rendered {duration:.1f}s at {width}x{height} to tscircuit-offline-docker.mp4')
