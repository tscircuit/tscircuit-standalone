TS Circuit offline Docker demonstration

The MP4 is rendered from the included real terminal event recording.
Long idle gaps are shortened to four seconds; output is unchanged.
Docker network mode is none throughout. The image was prepared beforehand.
The container starts with no project dependencies and an empty standalone cache.
Only the compiled standalone executable, a separate system Bun, and recording
scripts/evidence are mounted. No host package cache is supplied.

The separate Bun is initially absent from PATH, then explicitly added to show
that the CLI continues to invoke its embedded runtime. Its checksum is tested.
All ten CLI invocations are traced. The audit verifies external connection/send
attempts, allowing loopback traffic only when its peer is visible in the trace.
The intentionally failed curl internet probe is separate from CLI traces.

The starter circuit build succeeds but prints existing design and local catalog
warnings. These are retained, not edited out. This demonstrates the offline
installation fixes discussed in PR #46, not that every unrelated issue is fixed.

Files:
  tscircuit-offline-docker.mp4 - shareable H.264 video
  offline-demo.cast - original timed terminal recording
  terminal-output.txt - complete terminal output with ANSI codes
  *.trace - strace logs for each CLI invocation
  provenance.json / binary-sha256.txt - artifact identification
  Dockerfile / demo.sh / audit.py / record.py / render.py / reproduce.sh

Reproduce on Linux x64 with Docker, Python 3, Pillow, pyte, ffmpeg, and DejaVu fonts:
  bash reproduce.sh /absolute/path/to/tsci /absolute/path/to/bun
The container name tsci-offline-video must be unused. Build the standalone
executable from the commit in provenance.json first; the large executable is
not included in this evidence bundle. Building the image uses internet; the
recorded execution uses --network none.
