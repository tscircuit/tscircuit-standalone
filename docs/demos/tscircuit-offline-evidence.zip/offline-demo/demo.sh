#!/bin/bash
set -euo pipefail
export PATH=/usr/local/bin:/usr/bin:/bin
export HOME=/demo/home TSCIRCUIT_CACHE_DIR=/demo/cache TSCIRCUIT_CONFIG_DIR=/demo/config
export NO_COLOR=1 TERM=dumb
mkdir -p "$HOME" /evidence
cd /demo

chapter() { printf '\033[2J\033[H\033[1;36m%s\033[0m\n\n' "$1"; sleep 1; }
run() {
  printf '\033[1;32moffline:%s$\033[0m %s\n' "$PWD" "$1"
  sleep 1
  eval "$1"
  printf '\n'
  sleep 2
}
trace() {
  local label=$1
  shift
  strace -f -yy -s 256 -e trace=network,execve -o "/evidence/$label.trace" "$@"
}
export -f trace

chapter '01 / NETWORK DISABLED — fresh Docker container'
run 'ip -brief address; printf "Default routes: "; ip route | wc -l'
run 'curl --noproxy "*" --connect-timeout 2 --max-time 3 https://1.1.1.1; code=$?; test "$code" -ne 0 && echo "PASS: internet connection blocked"' || exit 1
run 'if command -v bun || command -v npm; then exit 1; else echo "No Bun or npm on PATH"; fi'
run 'test ! -e /demo/cache && echo "PASS: empty cache; only the standalone executable was supplied"'

chapter '02 / INIT — restore the embedded native Bun cache'
printf 'trace NAME COMMAND = strace -f -yy -s 256 -e trace=network,execve\n\n'
run 'trace init tsci init board --yes'
run 'test -f board/node_modules/tscircuit/package.json && echo "PASS: project and dependencies created offline"'
run 'cd /demo/board'

chapter '03 / REINSTALL — remove node_modules, keep the lockfile'
run 'rm -rf node_modules; test ! -d node_modules && echo "node_modules removed"'
run 'trace reinstall tsci install'
run 'test -f node_modules/tscircuit/package.json && echo "PASS: dependencies restored from native cache"'

chapter '04 / ADD AND REMOVE — native package-manager operations'
run 'trace add tsci install @types/react'
run 'trace remove tsci remove @types/react'
run 'trace restore tsci install @types/react'

chapter '05 / CACHE MISSES — fail locally without fetching'
run 'if trace missing tsci install tsci-deliberately-uncached-fixture; then exit 1; else echo "PASS: uncached package rejected"; fi'
run 'if trace tarball tsci install https://example.invalid/uncached.tgz; then exit 1; else echo "PASS: uncached tarball rejected"; fi'
run 'if trace git tsci install git+https://example.invalid/uncached.git; then exit 1; else echo "PASS: uncached Git dependency rejected"; fi'

chapter '06 / SYSTEM BUN — unchanged executable and PATH'
run 'export PATH=/opt/system-bun:$PATH; bun --version'
run 'before_path=$PATH; sha256sum /opt/system-bun/bun > /tmp/system-bun.sha256'
run 'trace system-bun tsci install'
run 'test "$PATH" = "$before_path" && sha256sum -c /tmp/system-bun.sha256'
run 'test -z "${BUN_BE_BUN-}" && echo "PASS: system Bun, PATH, and parent BUN_BE_BUN unchanged"'

chapter '07 / BUILD — compile the initialized circuit offline'
printf 'Starter design/catalog warnings are retained below; network audit follows.\n\n'
run 'trace build tsci build index.circuit.tsx'
run 'find dist -maxdepth 2 -type f | head -8'

chapter '08 / NETWORK AUDIT — all recorded CLI operations'
run 'python3 /demo/audit.py'
printf '\033[1;32mPASS: init / reinstall / add / remove / cache misses / build\nPASS: system Bun and PATH unchanged\n\033[0m'
sleep 5
